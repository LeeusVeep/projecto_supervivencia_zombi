
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';


const scene = new THREE.Scene();

scene.background = new THREE.Color(0x02030a);
scene.fog = new THREE.FogExp2(0x080b18, 0.025);

const camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    500
);

camera.position.set(0, 2, 10);
scene.add(camera);


const renderer = new THREE.WebGLRenderer({ antialias: true });

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

document.body.style.margin = '0';
document.body.style.overflow = 'hidden';
document.body.appendChild(renderer.domElement);


scene.add(new THREE.HemisphereLight(0xffffff, 0x444444, 2));

const luz = new THREE.DirectionalLight(0xffffff, 2);
luz.position.set(-10, 20, 10);
scene.add(luz);

// Luna aca

const geometriaLuna = new THREE.SphereGeometry(5, 32, 32);

const materialLuna = new THREE.MeshBasicMaterial({
    color: 0xe8edff
});

// Crear luna
const luna = new THREE.Mesh(
    geometriaLuna,
    materialLuna
);

// Posición en el cielo
luna.position.set(-35, 35, -80);

scene.add(luna);

// Luz que representa el resplandor lunar
const luzLunar = new THREE.PointLight(
    0x9aafe8,
    2,
    100
);

luzLunar.position.copy(luna.position);

scene.add(luzLunar);

// suelo aca

const suelo = new THREE.Mesh(
    new THREE.PlaneGeometry(40, 160),
    new THREE.MeshStandardMaterial({
        color: 0x555555,
        roughness: 1
    })
);

suelo.rotation.x = -Math.PI / 2;
suelo.position.set(0, 0, -40);
scene.add(suelo);

// carretera aca

const carretera = new THREE.Mesh(
    new THREE.PlaneGeometry(12, 120),
    new THREE.MeshStandardMaterial({
        color: 0x222222,
        roughness: 1
    })
);

carretera.rotation.x = -Math.PI / 2;
carretera.position.set(0, 0.02, -40);
scene.add(carretera);

// edificios aca

const loader3 = new THREE.TextureLoader();
const texture = await loader3.loadAsync('textures/textura_edificio.jpg');

function crearEdificio(x, z) {

    
    const edificio = new THREE.Mesh(
        new THREE.BoxGeometry(7, 9, 7),
        new THREE.MeshStandardMaterial({
            map: texture,
            color: 0x555555,
            roughness: 1
        })
    );

    edificio.position.set(x, 4.5, z);
    scene.add(edificio);
}

for (let i = 0; i < 6; i++) {
    crearEdificio(-11, -i * 18 - 5);
    crearEdificio(11, -i * 18 - 5);
}

// obstaculos como: caja, carro y una barrera

const obstaculos = [];

function crearObstaculo(tipo, x, z) {

    const grupo = new THREE.Group();

    if (tipo === "caja") {

        const caja = new THREE.Mesh(
            new THREE.BoxGeometry(2, 1.5, 1.5),
            new THREE.MeshStandardMaterial({
                color: 0x79502a,
                roughness: 1
            })
        );

        caja.position.y = 0.75;
        grupo.add(caja);

    }

    if (tipo === "barrera") {

        const barrera = new THREE.Mesh(
            new THREE.BoxGeometry(4, 1, 0.5),
            new THREE.MeshStandardMaterial({
                color: 0x950606,
                roughness: 1
            })
        );

        barrera.position.y = 0.5;
        grupo.add(barrera);

        // Franjas amarillas
        const franja = new THREE.Mesh(
            new THREE.BoxGeometry(4.05, 0.2, 0.55),
            new THREE.MeshStandardMaterial({
                color: 0xffcc00
            })
        );

        franja.position.y = 0.65;
        grupo.add(franja);

    }

    if (tipo === "auto") {

        const cuerpo = new THREE.Mesh(
            new THREE.BoxGeometry(3, 1.3, 5),
            new THREE.MeshStandardMaterial({
                color: 0x333344,
                roughness: 0.8
            })
        );

        cuerpo.position.y = 0.9;
        grupo.add(cuerpo);

        const techo = new THREE.Mesh(
            new THREE.BoxGeometry(2.5, 1, 2.5),
            new THREE.MeshStandardMaterial({
                color: 0x111122
            })
        );

        techo.position.y = 2;
        grupo.add(techo);

        // Ruedas
        const geometriaRueda = new THREE.CylinderGeometry(
            0.45, 0.45, 0.3, 16
        );

        const materialRueda = new THREE.MeshStandardMaterial({
            color: 0x080808
        });

        for (const lado of [-1, 1]) {
            for (const frente of [-1, 1]) {

                const rueda = new THREE.Mesh(
                    geometriaRueda,
                    materialRueda
                );

                rueda.rotation.z = Math.PI / 2;

                rueda.position.set(
                    lado * 1.5,
                    0.45,
                    frente * 1.5
                );

                grupo.add(rueda);

            }
        }

    }

    grupo.position.set(x, 0, z);
    grupo.userData.esObstaculo = true;
    scene.add(grupo);
    obstaculos.push(grupo);

}

// colision

function comprobarColision(x, z) {

    const radioJugador = 0.7;

    for (const obstaculo of obstaculos) {

        const caja = new THREE.Box3()
            .setFromObject(obstaculo);

        caja.expandByScalar(radioJugador);

        if (
            x >= caja.min.x &&
            x <= caja.max.x &&
            z >= caja.min.z &&
            z <= caja.max.z
        ) {
            return true;
        }

    }

    return false;

}


// Crear obstáculos distribuidos por la carretera

const posicionesObstaculos = [

    { tipo: "auto", x: -3, z: -18 },
    { tipo: "caja", x: 3, z: -28 },
    { tipo: "barrera", x: 0, z: -40 },
    { tipo: "auto", x: 3, z: -52 },
    { tipo: "caja", x: -3, z: -65 },
    { tipo: "barrera", x: 0, z: -75 },
    { tipo: "auto", x: -3, z: -88 },
    { tipo: "caja", x: 3, z: -100 }

];

posicionesObstaculos.forEach((posicion) => {

    crearObstaculo(
        posicion.tipo,
        posicion.x,
        posicion.z
    );

});

// Cargamos nuestro helicoptero aca

const loader = new GLTFLoader();

const gltf = await loader.loadAsync('./models/helicoptero.glb');

const helicopter = gltf.scene;
helicopter.scale.setScalar(2.75);
helicopter.position.set(0, -0.1, -110);
helicopter.rotation.y = 7.75;
scene.add(helicopter);


// ==================== SISTEMA DE ZOMBIS ====================

const zombis = [];

function cargarZombie(ruta, posicion) {

    loader.load(ruta, (gltf) => {

        // Grupo principal del zombie
        const zombie = new THREE.Group();

        // Modelo 3D
        const modelo = gltf.scene;

        // Calcular dimensiones
        const caja = new THREE.Box3().setFromObject(modelo);

        const tamaño = new THREE.Vector3();
        const centro = new THREE.Vector3();

        caja.getSize(tamaño);
        caja.getCenter(centro);

        // Ajustar altura a aproximadamente 2 unidades
        if (tamaño.y > 0) {

            const escala = 2 / tamaño.y;

            modelo.scale.setScalar(escala);

            // Actualizar dimensiones
            modelo.updateMatrixWorld(true);

            const nuevaCaja = new THREE.Box3().setFromObject(modelo);

            const nuevoCentro = new THREE.Vector3();

            nuevaCaja.getCenter(nuevoCentro);

            // Centrar horizontalmente y apoyar en el suelo
            modelo.position.x -= nuevoCentro.x;
            modelo.position.y -= nuevaCaja.min.y;
            modelo.position.z -= nuevoCentro.z;

        }

        // Agregar modelo al grupo
        zombie.add(modelo);

        // Posición en el mapa
        zombie.position.set(
            posicion.x,
            posicion.y,
            posicion.z
        );

        // ==================== DATOS DEL ZOMBI ====================

        zombie.userData.esZombie = true;
        zombie.userData.vida = 2;
        zombie.userData.eliminado = false;

         // Sistema de inteligencia artificial
        zombie.userData.estado = "inactivo";
        zombie.userData.rangoDeteccion = 10;
        zombie.userData.velocidad = 2.5;

        // Nombre para identificarlo
        zombie.name = "Zombie";
        scene.add(zombie);
        zombis.push(zombie);
        console.log("ZOMBI AGREGADO AL MAPA");

    }, undefined, (error) => {

        console.error("Error cargando zombie:", error);

    });

}

// ia bajisima del zombie

function actualizarZombis(delta) {

    if (gameOver) return;

    zombis.forEach((zombie) => {

        // tas muerto mijo, no hagas nada :v
        if (zombie.userData.eliminado) return;

        // Calcular distancia entre jugador y zombi
        const distancia = new THREE.Vector2(
            camera.position.x - zombie.position.x,
            camera.position.z - zombie.position.z
        ).length();

        // there is no brain around

        if (zombie.userData.estado === "inactivo") {

            // Comprobar si el jugador entra en el rango
            if (distancia <= zombie.userData.rangoDeteccion) {

                zombie.userData.estado = "activo"; 
                console.log("¡ZOMBI ALERTADO!");

            }

        }

        // rawr i want that brain - zombie headcrab

        if (zombie.userData.estado === "activo") {

            // Dirección hacia el jugador
            const direccion = new THREE.Vector3(
                camera.position.x - zombie.position.x,
                0,
                camera.position.z - zombie.position.z
            );

            // Evitar división entre cero
            if (direccion.lengthSq() > 0.001) {

                direccion.normalize();

                // Girar hacia el jugador
                zombie.rotation.y = Math.atan2(
                    direccion.x,
                    direccion.z
                );

                // Perseguir al jugador
                zombie.position.x +=
                    direccion.x *
                    zombie.userData.velocidad *
                    delta;

                zombie.position.z +=
                    direccion.z *
                    zombie.userData.velocidad *
                    delta;

            }
            // Actualizar distancia después del movimiento
            let distancia = new THREE.Vector2(
                camera.position.x - zombie.position.x,
                camera.position.z - zombie.position.z
            ).length();

            // Detectar contacto
            if (distancia <= 1.2) {

                terminarPartida();

                return;

            }

        }

    });

}


// un zombi te toca, moriste mano ;(

let gameOver = false;
const pantallaGameOver = document.createElement("div");

pantallaGameOver.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;

    background: rgba(0, 0, 0, 0.85);

    display: none;
    justify-content: center;
    align-items: center;
    flex-direction: column;

    z-index: 9999;
    font-family: Arial, sans-serif;
`;

pantallaGameOver.innerHTML = `
    <h1 style="
        color: #ff0000;
        font-size: 85px;
        font-weight: bold;
        text-shadow: 0 0 20px red;
        margin: 0;
    ">
        GAME OVER
    </h1>

    <p style="
        color: white;
        font-size: 22px;
        margin-top: 20px;
    ">
        LOS ZOMBIS HAN COMIDO TU CEREBRO!!!
    </p>
`;

document.body.appendChild(pantallaGameOver);


// Funcion para terminar partida
function terminarPartida() {

    if (gameOver) return;

    gameOver = true;
    pantallaGameOver.style.display = "flex";
    document.exitPointerLock();

}

// get to the chopper bois

const pantallaVictoria = document.createElement("div");

pantallaVictoria.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 20, 0, 0.90);
    display: none;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    z-index: 10000;
    font-family: Arial, sans-serif;
    color: white;
    text-align: center;
`;

pantallaVictoria.innerHTML = `
    <h1 style="font-size: 65px; color: #00ff66;">
        ¡RESCATE EXITOSO!
    </h1>

    <h2>¡HAS SOBREVIVIDO!</h2>

    <p>Has llegado al helicóptero y conseguido escapar de los zombis.</p>
`;

document.body.appendChild(pantallaVictoria);

function terminarVictoria() {

    if (gameOver) return;

    gameOver = true;
    pantallaVictoria.style.display = "flex";
    document.exitPointerLock();

    console.log("¡VICTORIA! HAS LLEGADO AL RESCATE");
}

function comprobarRescate() {

    if (gameOver) return;

    const distancia = new THREE.Vector2(
        camera.position.x - helicopter.position.x,
        camera.position.z - helicopter.position.z
    ).length();

    if (distancia <= 4.5) {
        terminarVictoria();
    }
}


// creamos las posiciones de los zombis aca

const posicionesZombis = [

    { x: -5, y: 0, z: -10 },
    { x: -3, y: 0, z: -5 },
    { x: 3, y: 0, z: -5 },
    { x: 5,  y: 0, z: -15 },
    { x: -5, y: 0, z: -45 },
    { x: -5, y: 0, z: -40 },
    { x: 0,  y: 0, z: -55 },
    { x: -5, y: 0, z: -70 },
    { x: 5,  y: 0, z: -80 },
    { x: 0,  y: 0, z: -80 },
    { x: -5,  y: 0, z: -80 },
    { x: -5, y: 0, z: -95 },
    { x: 5,  y: 0, z: -100 },
    { x: 0,  y: 0, z: -100 }
];

// cargar modelo
posicionesZombis.forEach((posicion) => {

    cargarZombie(
        "./models/headcrab_zombi.glb",
        posicion
    );

});


// movement

const teclas = {};

window.addEventListener('keydown', (e) => {
    teclas[e.code] = true;
});

window.addEventListener('keyup', (e) => {
    teclas[e.code] = false;
});

const velocidad = 6;

function moverJugador(delta) {

    if (gameOver) return;

    const direccion = new THREE.Vector3();

    if (teclas['KeyW']) direccion.z -= 1;
    if (teclas['KeyS']) direccion.z += 1;
    if (teclas['KeyA']) direccion.x -= 1;
    if (teclas['KeyD']) direccion.x += 1;

    direccion.normalize();

    const movimiento = direccion.applyQuaternion(
        camera.quaternion
    );

    const nuevoX = camera.position.x +
    movimiento.x * velocidad * delta;

const nuevoZ = camera.position.z +
    movimiento.z * velocidad * delta;

// Comprobar colisiones por separado
if (!comprobarColision(nuevoX, camera.position.z)) {
    camera.position.x = nuevoX;
}

if (!comprobarColision(camera.position.x, nuevoZ)) {
    camera.position.z = nuevoZ;
}

    camera.position.x = THREE.MathUtils.clamp(
        camera.position.x, -17, 17
    );

    camera.position.z = THREE.MathUtils.clamp(
        camera.position.z, -110, 15
    );
}

// mouse

renderer.domElement.addEventListener('click', () => {
    renderer.domElement.requestPointerLock();
});

let rotacionY = 0;
let rotacionX = 0;

document.addEventListener('mousemove', (e) => {

    if (document.pointerLockElement !== renderer.domElement) return;

    rotacionY -= e.movementX * 0.002;
    rotacionX -= e.movementY * 0.002;

    rotacionX = THREE.MathUtils.clamp(
        rotacionX, -1.4, 1.4
    );

    camera.rotation.order = 'YXZ';
    camera.rotation.y = rotacionY;
    camera.rotation.x = rotacionX;
});

// animacion

const reloj = new THREE.Clock();

renderer.setAnimationLoop(() => {

    const delta = Math.min(reloj.getDelta(), 0.05);

    moverJugador(delta);
    comprobarRescate();
    actualizarZombis(delta);
    actualizarCajasMunicion();

    renderer.render(scene, camera);

});


window.addEventListener('resize', () => {

    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize(window.innerWidth, window.innerHeight);
});


// "to the next gta!"  


const weaponGroup = new THREE.Group();

camera.add(weaponGroup);

// Posición del grupo delante de la cámara
weaponGroup.position.set(0.85, -0.05, -1.2);

const armas = {};
let armaActual = null;


// hud de municion 

const hudMunicion = document.createElement("div");

hudMunicion.style.cssText = `
    position: fixed;
    right: 45px;
    bottom: 35px;
    color: white;
    font-family: Arial, sans-serif;
    text-align: right;
    pointer-events: none;
    z-index: 1000;
    text-shadow: 2px 2px 5px black;
`;

hudMunicion.innerHTML = `
    <div id="nombreArma"
        style="font-size:16px; color:#bbbbbb;
        letter-spacing:3px; margin-bottom:5px;">
        PISTOLA
    </div>

    <div style="font-size:38px;font-weight:bold;">
        <span id="municionActual">12</span>
        <span style="font-size:22px;color:#999"> / </span>
        <span id="municionReserva"
            style="font-size:22px;color:#bbbbbb">60</span>
    </div>

    <div style="font-size:11px;color:#aaa;
        letter-spacing:3px;margin-top:3px;">
        MUNICION
    </div>

    <div id="estadoRecarga"
        style="font-size:12px;color:#ffcc55;
        margin-top:8px;"></div>
`;

document.body.appendChild(hudMunicion);


// Stats Municion

const datosMunicion = {

    pistola: {
        cargador: 8,
        maxCargador: 8,
        reserva: 32,
        maxReserva: 80,
        cadencia: 300,
        tiempoRecarga: 1200,
        recargando: false,
        ultimoDisparo: 0
    },

    rifle_ak47: {
        cargador: 30,
        maxCargador: 30,
        reserva: 60,
        maxReserva: 240,
        cadencia: 20,
        tiempoRecarga: 1800,
        recargando: false,
        ultimoDisparo: 0
    }

};

// maxima municion?

// Creamos las cajas de municion al mapa
const cajasMunicion = [];

function crearCajaMunicion(tipo, posicion) {

    const caja = new THREE.Group();

    // Color dependiendo del arma
    const colorCaja = tipo === "pistola"
        ? 0x2266cc
        : 0x228833;

    // Cuerpo de la caja
    const cuerpo = new THREE.Mesh(
        new THREE.BoxGeometry(0.8, 0.5, 0.6),
        new THREE.MeshStandardMaterial({
            color: colorCaja,
            roughness: 0.8
        })
    );

    caja.add(cuerpo);

    // Franja amarilla de la caja
    const franja = new THREE.Mesh(
        new THREE.BoxGeometry(0.82, 0.12, 0.62),
        new THREE.MeshStandardMaterial({
            color: 0xffcc00
        })
    );

    franja.position.y = 0.1;
    caja.add(franja);

    // Balas decorativas
    const balaGeometria = new THREE.CylinderGeometry(
        0.07, 0.07, 0.3, 8
    );

    const balaMaterial = new THREE.MeshStandardMaterial({
        color: 0xc9a43b,
        metalness: 0.7,
        roughness: 0.3
    });

    for (let i = 0; i < 3; i++) {

        const bala = new THREE.Mesh(
            balaGeometria,
            balaMaterial
        );

        bala.position.set(
            -0.2 + i * 0.2,
            0.4,
            0
        );

        caja.add(bala);

    }

    // Posicion en el mapa
    caja.position.set(
        posicion.x,
        0.3,
        posicion.z
    );

    // Datos de la caja
    caja.userData.tipo = tipo;
    caja.userData.cantidad = tipo === "pistola" ? 12 : 30;

    scene.add(caja);
    cajasMunicion.push(caja);

}

// posicion de municion

const posicionesMunicion = [

    { tipo: "pistola", x: -12, z: -12 },
    { tipo: "pistola", x: 10, z: -45 },
    { tipo: "pistola", x: -3, z: -85 },
    { tipo: "rifle_ak47", x: 3, z: -25 },
    { tipo: "rifle_ak47", x: -3, z: -60 },
    { tipo: "rifle_ak47", x: 3, z: -95 }

];

posicionesMunicion.forEach((posicion) => {

    crearCajaMunicion(
        posicion.tipo,
        posicion
    );

});

// ==================== RECOGER MUNICION ====================

function actualizarCajasMunicion() {

    for (let i = cajasMunicion.length - 1; i >= 0; i--) {

        const caja = cajasMunicion[i];

        // Calcular distancia entre jugador y caja
        const distancia = new THREE.Vector2(
            camera.position.x - caja.position.x,
            camera.position.z - caja.position.z
        ).length();

        // Comprobar proximidad
        if (distancia <= 1.8) {

            const tipo = caja.userData.tipo;
            const cantidad = caja.userData.cantidad;

            const datos = datosMunicion[tipo];

            // Comprobar si todavia puede recoger municion
            if (datos.reserva >= datos.maxReserva) {
                continue;
            }

            // Agregar municion
            const espacioDisponible =
                datos.maxReserva - datos.reserva;

            const municionRecogida = Math.min(
                cantidad,
                espacioDisponible
            );

            datos.reserva += municionRecogida;

            // Eliminar caja del escenario
            scene.remove(caja);
            cajasMunicion.splice(i, 1);
            actualizarHUD();

            console.log(
                "MUNICION RECOGIDA:",
                tipo,
                "+",
                municionRecogida
            );

        }

    }

}


// Hud

function actualizarHUD() {

    if (!armaActual) return;

    const datos = datosMunicion[armaActual];

    if (!datos) return;

    document.getElementById("nombreArma").textContent =
        armaActual.toUpperCase();

    document.getElementById("municionActual").textContent =
        datos.cargador;

    document.getElementById("municionReserva").textContent =
        datos.reserva;

    document.getElementById("estadoRecarga").textContent =
        datos.recargando ? "RECARGANDO..." : "";

}



function cargarArma(nombre, ruta) {

    loader.load(ruta, (gltf) => {

        const arma = gltf.scene;

        // Obtener dimensiones del modelo
        const caja = new THREE.Box3().setFromObject(arma);
        const centro = new THREE.Vector3();
        const tamaño = new THREE.Vector3();

        caja.getCenter(centro);
        caja.getSize(tamaño);

        console.log("Dimensiones:", tamaño);

        arma.position.sub(centro);

        const max = Math.max(tamaño.x, tamaño.y, tamaño.z);

        if (max > 0) {
            arma.scale.setScalar(1.5 / max);
        }

        if (nombre === "rifle_ak47") {
            arma.rotation.set(0, 15.75, 0);
            arma.position.set(-0.4, -0.25, 0.75);
        } else {
            arma.rotation.set(5, 5, 5);
        }

        // Revisar materiales
        arma.traverse((objeto) => {
            if (objeto.isMesh) {
                objeto.visible = true;

                if (objeto.material) {
                    objeto.material.side = THREE.DoubleSide;
                    objeto.material.needsUpdate = true;
                }
            }
        });

        // Agregar a la cámara
        weaponGroup.add(arma);

        armas[nombre] = arma;

        if (!armaActual) {
            cambiarArma(nombre);
        }

        console.log("Modelo listo:", nombre);

    }, undefined, (error) => {

        console.error("Error al cargar GLB:", error);

    });

}

cargarArma("pistola", "./models/pistola.glb");
cargarArma("rifle_ak47", "./models/rifle.glb");


// Cambio de ARMAS


function cambiarArma(nombre) {

    if (!armas[nombre]) return;

    for (const key in armas) {
        armas[key].visible = false;
    }

    armas[nombre].visible = true;

    armaActual = nombre;

    actualizarHUD();

    console.log("Arma seleccionada:", nombre);
}



// Shooting system :o

const raycaster = new THREE.Raycaster();

const centroPantalla = new THREE.Vector2(0, 0);

function disparar() {

    if (gameOver) return;

    if (!armaActual) return;

    const datos = datosMunicion[armaActual];

    if (!datos) return;

    // No disparar durante la recarga
    if (datos.recargando) return;

    // Comprobar cadencia
    const ahora = performance.now();

    if (ahora - datos.ultimoDisparo < datos.cadencia) {
        return;
    }

    datos.ultimoDisparo = ahora;

    // Comprobar municion
    if (datos.cargador <= 0) {
        actualizarHUD();
        return;
    }

    // Consumir una bala
    datos.cargador--;

    actualizarHUD();

    // Lanzar rayo desde el centro de la camara
    raycaster.setFromCamera(centroPantalla, camera);

    // Excluir la camara y sus armas
    const objetosMundo = scene.children.filter(
        objeto => objeto !== camera
    );

    const impactos = raycaster.intersectObjects(
        objetosMundo,
        true
    );

    if (impactos.length > 0) {

    const impacto = impactos[0];

    // Buscar si el objeto impactado pertenece a un zombie
    let objeto = impacto.object;

    while (objeto && !objeto.userData.esZombie) {
        objeto = objeto.parent;
    }

    // Comprobar si encontramos un zombie
    if (objeto && objeto.userData.esZombie) {

        const zombie = objeto;

        // Evitar impactos en zombis eliminados
        if (zombie.userData.eliminado) return;

        // Quitar un punto de vida
        zombie.userData.vida--;

        console.log(
            "ZOMBI IMPACTADO. VIDA RESTANTE:",
            zombie.userData.vida
        );

        // Comprobar si murió
        if (zombie.userData.vida <= 0) {

            zombie.userData.eliminado = true;

            // Eliminar del escenario
            scene.remove(zombie);

            // Eliminar de la lista
            const indice = zombis.indexOf(zombie);

            if (indice !== -1) {
                zombis.splice(indice, 1);
            }

            console.log("¡ZOMBI ELIMINADO!");

        }

    } else {

        console.log("Impacto en:", impacto.object.name);

    }

}

    console.log("DISPARO:", armaActual);

}


// aca se dispara

document.addEventListener("mousedown", (e) => {

    if (e.button !== 0) return;

    // Solo disparar cuando el mouse esta bloqueado
    if (document.pointerLockElement !== renderer.domElement) {
        return;
    }

    disparar();

});


// Recargar

function recargar() {

    if (gameOver) return;

    if (!armaActual) return;

    const nombre = armaActual;
    const datos = datosMunicion[nombre];

    if (!datos) return;
    if (datos.recargando) return;
    if (datos.cargador >= datos.maxCargador) return;
    if (datos.reserva <= 0) return;
    datos.recargando = true;

    actualizarHUD();

    console.log("RECARGANDO:", nombre);

    setTimeout(() => {

        const faltantes =
            datos.maxCargador - datos.cargador;
        const cantidad = Math.min(
            faltantes,
            datos.reserva
        );
        datos.cargador += cantidad;
        datos.reserva -= cantidad;
        datos.recargando = false;
        actualizarHUD();
        console.log("RECARGA COMPLETADA:", nombre);

    }, datos.tiempoRecarga);

}


// Crosshair

const mira = document.createElement("div");

mira.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 5px;
    height: 5px;
    background: white;
    border-radius: 50%;
    box-shadow: 0 0 3px black;
    pointer-events: none;
    z-index: 1000;
`;

document.body.appendChild(mira);



// ==================== TECLA R ====================

window.addEventListener("keydown", (e) => {

    if (e.code === "KeyR" && !e.repeat) {
        recargar();
    }

});


window.addEventListener("keydown", (e) => {

    if (e.code === "Digit1") cambiarArma("pistola");

    if (e.code === "Digit2") cambiarArma("rifle_ak47");

});





